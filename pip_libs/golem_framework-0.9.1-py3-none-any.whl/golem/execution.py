""" Stored values specific to a single test execution. """

browser = None
browser_definition = None
browsers = {}
steps = []
data = None
secrets = None
description = None
errors = []
settings = None
test_name = None
test_dirname = None
test_path = None
project_name = None
project_path = None
testdir = None
report_directory = None
logger = None
timers = {}
tags = []
environment = None
