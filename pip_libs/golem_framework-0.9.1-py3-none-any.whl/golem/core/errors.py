
invalid_test_directory = ('Error: {} is not an valid Golem test directory; '
                          '.golem file not found')
