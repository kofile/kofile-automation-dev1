"""Global values for current session"""

testdir = None

settings = {}
