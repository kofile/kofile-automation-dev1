

class ResultsEnum:
    PENDING = 'pending'
    RUNNING = 'running'
    FAILURE = 'failure'
    ERROR = 'error'
    CODE_ERROR = 'code error'
    SUCCESS = 'success'
    STOPPED = 'stopped'
    NOT_RUN = 'not run'
    SKIPPED = 'skipped'
